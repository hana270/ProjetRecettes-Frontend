export class Recette {
    idRecette!: number;        
    dateCreation!: Date;       
    description!: string;       
    nomRecette!: string;      

}